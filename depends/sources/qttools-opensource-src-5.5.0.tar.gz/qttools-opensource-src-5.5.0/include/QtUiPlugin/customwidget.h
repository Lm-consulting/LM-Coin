#include "../../src/designer/src/uiplugin/customwidget.h"
