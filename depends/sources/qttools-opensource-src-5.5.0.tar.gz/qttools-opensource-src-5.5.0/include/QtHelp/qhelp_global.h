#include "../../src/assistant/help/qhelp_global.h"
