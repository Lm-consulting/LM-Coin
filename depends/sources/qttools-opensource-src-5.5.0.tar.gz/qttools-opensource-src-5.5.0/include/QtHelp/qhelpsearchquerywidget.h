#include "../../src/assistant/help/qhelpsearchquerywidget.h"
