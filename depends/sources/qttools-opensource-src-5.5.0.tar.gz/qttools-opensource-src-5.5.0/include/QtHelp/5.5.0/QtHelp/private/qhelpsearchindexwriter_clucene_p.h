#include "../../../../../src/assistant/help/qhelpsearchindexwriter_clucene_p.h"
