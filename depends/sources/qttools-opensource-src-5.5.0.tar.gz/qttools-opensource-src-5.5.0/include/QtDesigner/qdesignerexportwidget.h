#ifndef DEPRECATED_HEADER_QtDesigner_qdesignerexportwidget_h
#define DEPRECATED_HEADER_QtDesigner_qdesignerexportwidget_h
#if defined(__GNUC__)
#  warning Header <QtDesigner/qdesignerexportwidget.h> is deprecated. Please include <QtUiPlugin/qdesignerexportwidget.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtDesigner/qdesignerexportwidget.h> is deprecated. Please include <QtUiPlugin/qdesignerexportwidget.h> instead.")
#endif
#include <QtUiPlugin/qdesignerexportwidget.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
