#include "../../../../../src/designer/src/lib/shared/widgetdatabase_p.h"
