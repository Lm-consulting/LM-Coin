#include "../../../../../src/designer/src/lib/shared/widgetfactory_p.h"
