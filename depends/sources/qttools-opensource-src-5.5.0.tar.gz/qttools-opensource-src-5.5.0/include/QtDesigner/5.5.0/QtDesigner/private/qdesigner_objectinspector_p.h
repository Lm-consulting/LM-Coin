#include "../../../../../src/designer/src/lib/shared/qdesigner_objectinspector_p.h"
