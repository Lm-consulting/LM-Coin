#include "../../../../../src/designer/src/lib/shared/richtexteditor_p.h"
