#include "../../../../../src/designer/src/lib/shared/pluginmanager_p.h"
