#include "../../../../../src/designer/src/lib/shared/qdesigner_tabwidget_p.h"
