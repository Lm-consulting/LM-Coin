#include "../../../../../src/designer/src/lib/shared/qtresourceview_p.h"
