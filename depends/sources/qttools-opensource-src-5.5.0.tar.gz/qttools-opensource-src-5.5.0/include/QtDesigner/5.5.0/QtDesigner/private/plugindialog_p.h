#include "../../../../../src/designer/src/lib/shared/plugindialog_p.h"
