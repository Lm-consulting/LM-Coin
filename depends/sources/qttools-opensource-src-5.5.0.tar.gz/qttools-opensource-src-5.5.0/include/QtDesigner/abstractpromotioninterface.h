#include "../../src/designer/src/lib/sdk/abstractpromotioninterface.h"
