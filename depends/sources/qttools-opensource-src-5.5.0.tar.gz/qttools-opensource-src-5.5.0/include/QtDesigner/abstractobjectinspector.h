#include "../../src/designer/src/lib/sdk/abstractobjectinspector.h"
