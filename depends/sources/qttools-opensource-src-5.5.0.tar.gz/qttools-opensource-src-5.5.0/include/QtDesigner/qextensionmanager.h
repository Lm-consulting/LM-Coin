#include "../../src/designer/src/lib/extension/qextensionmanager.h"
