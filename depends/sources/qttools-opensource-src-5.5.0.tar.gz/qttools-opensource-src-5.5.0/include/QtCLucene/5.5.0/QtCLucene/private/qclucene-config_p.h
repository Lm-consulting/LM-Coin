#include "../../../../../src/assistant/clucene/qclucene-config_p.h"
