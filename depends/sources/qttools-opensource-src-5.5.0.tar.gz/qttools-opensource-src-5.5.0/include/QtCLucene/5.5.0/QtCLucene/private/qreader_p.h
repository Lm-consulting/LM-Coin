#include "../../../../../src/assistant/clucene/qreader_p.h"
