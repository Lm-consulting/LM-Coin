#include "../../../../../src/assistant/clucene/qfield_p.h"
