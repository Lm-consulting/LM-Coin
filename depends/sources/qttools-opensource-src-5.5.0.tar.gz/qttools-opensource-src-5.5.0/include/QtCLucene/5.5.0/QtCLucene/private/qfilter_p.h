#include "../../../../../src/assistant/clucene/qfilter_p.h"
