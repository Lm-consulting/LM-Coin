#include "../../../../../src/assistant/clucene/qhits_p.h"
