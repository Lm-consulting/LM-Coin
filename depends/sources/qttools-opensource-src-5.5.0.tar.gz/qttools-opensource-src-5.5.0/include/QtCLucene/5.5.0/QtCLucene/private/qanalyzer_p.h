#include "../../../../../src/assistant/clucene/qanalyzer_p.h"
