<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>QObject</name>
    <message>
        <location filename="myi18nobject.cpp" line="15"/>
        <source>Hello, world!</source>
        <translation>Hallo, Welt</translation>
    </message>
</context>
</TS>
