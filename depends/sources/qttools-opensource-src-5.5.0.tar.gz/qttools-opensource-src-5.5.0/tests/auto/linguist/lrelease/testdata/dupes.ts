<?xml version="1.0"?>
<!DOCTYPE TS>
<TS version="1.1">
<context>
    <name>FindDialog</name>
    <message>
        <location filename="finddialog.cpp" line="109"/>
        <source>Search reached start of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="finddialog.cpp" line="111"/>
        <source>Text not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text not found</source>
        <translation type="obsolete"></translation>
    </message>
</context>
</TS>
