<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Context1</name>
    <message>
        <source>Foo</source>
        <translation>in first context</translation>
    </message>
</context>
<context>
    <name>Context2</name>
    <message>
        <source>Bar</source>
        <translation>in second context</translation>
    </message>
</context>
<context>
    <name>Action1</name>
    <message>
        <location filename="main.cpp" line="14"/>
        <source>Component Name</source>
        <translation>translation in first context</translation>
    </message>
    <message>
        <source>Fooish bar</source>
        <translation>the bar is fooish</translation>
    </message>
</context>
<context>
    <name>Action2</name>
    <message>
        <location filename="main.cpp" line="20"/>
        <source>Component Name</source>
        <translation>translation in second context</translation>
    </message>
</context>
<context>
    <name>Action3</name>
    <message>
        <location filename="main.cpp" line="26"/>
        <source>Component Name</source>
        <translation>translation in third context</translation>
    </message>
</context>
</TS>
