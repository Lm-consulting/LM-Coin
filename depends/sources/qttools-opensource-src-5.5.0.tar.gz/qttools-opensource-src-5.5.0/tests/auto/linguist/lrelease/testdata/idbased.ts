<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name></name>
    <message id="test_id">
        <source>Completely irrelevant source text</source>
        <translation>This is a test string.</translation>
    </message>
    <message id="untranslated_id">
        <source>This has no translation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message id="this_another_id">
        <source>Foo bar.</source>
        <comment>Warn me!</comment>
    </message>
    <message>
        <source>Drop me!</source>
    </message>
    <message id="one_id">
        <source></source>
    </message>
    <message id="two_id">
        <source></source>
    </message>
</context>
</TS>
