<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Dialog2</name>
    <message numerus="yes">
        <location filename="main.cpp" line="29"/>
        <source>%n files</source>
        <comment>plural form</comment>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="30"/>
        <source>%n cars</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="31"/>
        <source>&amp;Find %n cars</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="32"/>
        <source>Search in %n items?</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="33"/>
        <source>%1. Search in %n items?</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="main.cpp" line="34"/>
        <source>Age: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="35"/>
        <source>There are %n house(s)</source>
        <comment>Plurals and function call</comment>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="53"/>
        <source>QTranslator</source>
        <comment>Simple</comment>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="54"/>
        <source>QTranslator</source>
        <comment>Simple with comment</comment>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="55"/>
        <source>QTranslator</source>
        <comment>Plural without comment</comment>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="57"/>
        <source>QTranslator</source>
        <comment>Plural with comment</comment>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="main.cpp" line="102"/>
        <source>func3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="main.cpp" line="13"/>
        <source>QT_LAYOUT_DIRECTION</source>
        <comment>Translate this string to the string &apos;LTR&apos; in left-to-right languages or to &apos;RTL&apos; in right-to-left languages (such as Hebrew and Arabic) to get proper widget layout.</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message numerus="yes">
        <location filename="main.cpp" line="40"/>
        <source>Plurals, QCoreApplication</source>
        <comment>%n house(s)</comment>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="41"/>
        <source>Plurals, QCoreApplication</source>
        <comment>%n car(s)</comment>
        <translation>
            <numerusform>looks quite finished</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="main.cpp" line="42"/>
        <source>Plurals, QCoreApplication</source>
        <comment>%n horse(s)</comment>
        <translation type="vanished">
            <numerusform>looks kinda vanished</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>TestClass</name>
    <message>
        <location filename="main.cpp" line="116"/>
        <source>inline function</source>
        <comment>TestClass</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="120"/>
        <source>inline function 2</source>
        <comment>TestClass</comment>
        <translation type="vanished">just fine here</translation>
    </message>
    <message>
        <location filename="main.cpp" line="124"/>
        <source>static inline function</source>
        <comment>TestClass</comment>
        <translation type="obsolete">not quite fine here</translation>
    </message>
</context>
<context>
    <name>Bizarre ~ and | context~</name>
    <message>
        <source>just something</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>something else</source>
        <comment>comment with | and ~ and so~</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>just something obsolete</source>
        <translation type="obsolete">translated obsoletion</translation>
    </message>
    <message>
        <source>something else obsolete</source>
        <comment>comment with | and ~ and so~</comment>
        <translation type="obsolete">another translated obsoletion</translation>
    </message>
</context>
</TS>
