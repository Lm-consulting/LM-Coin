<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>a</name>
    <message>
        <location filename="a.cpp" line="93"/>
        <source>First String</source>
        <translation></translation>
    </message>
    <message>
        <location filename="a.cpp" line="380"/>
        <source>Duplicated String</source>
        <translation></translation>
    </message>
</context>
</TS>
