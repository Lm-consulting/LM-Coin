<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>Assistant</name>
    <message>
        <source>Not plural</source>
        <translation>Kein plural</translation>
    </message>
    <message numerus="yes">
        <source>%n document(s) found.</source>
        <translation>
            <numerusform>1 Dokument gefunden.</numerusform>
            <numerusform>%n Dokumente gefunden.</numerusform>
        </translation>
    </message>
</context>
</TS>
